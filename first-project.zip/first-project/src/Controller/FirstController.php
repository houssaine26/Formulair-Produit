<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

final class FirstController extends AbstractController
{
    #[Route('/first', name: 'app_first')]
    public function index(): Response
    {
        $number=15;
       return $this->render('first/index.html.twig', [
            'controller_name' => 'FirstController',
            'mon_nombre'=> $number,
        ]);
    }
}

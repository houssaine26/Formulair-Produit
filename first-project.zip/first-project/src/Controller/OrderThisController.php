<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use App\Formulair\Type\OrderThisType;

final class OrderThisController extends AbstractController
{
    #[Route('/order/this', name: 'app_order_this')]
    public function index(): Response

    { 
        $OrderThisForm = $this->createForm(OrderThisType::class);

        return $this->render('order_this/index.html.twig', [
            'form' => $OrderThisForm,
        ]);
    }
}

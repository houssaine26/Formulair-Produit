<?php
declare(strict_types=1);

namespace App\Formulair\Type;

;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;

class OrderThisType extends AbstractType{

public function buildForm(FormBuilderInterface $builder, array $options): void
{
    $builder->add('quantity', IntegerType::class ,[
    'label' => 'Quantity',
    'attr' =>[
        'min'=>1,
        'max'=>100,
        'class'=>'form-control',
    ]
    ])
        ->add('color',ChoiceType::class,[

            'label'=>'Select Color',
            'choices'=>[
                'Matte Black' => 'black',
                    'Pearl White' => 'white',
                    'Silver' => 'silver',
            ],
            'attr'=>[
                'class'=>'form-select'
            ]
            ]);
        }

}
































?>